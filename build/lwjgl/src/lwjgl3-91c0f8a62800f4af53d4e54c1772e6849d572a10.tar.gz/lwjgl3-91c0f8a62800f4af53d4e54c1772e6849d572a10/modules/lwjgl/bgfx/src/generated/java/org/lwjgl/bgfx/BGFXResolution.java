/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.bgfx;

import org.jspecify.annotations.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

/**
 * <pre>{@code
 * struct bgfx_resolution_t {
 *     bgfx_texture_format_t formatColor;
 *     bgfx_texture_format_t formatDepthStencil;
 *     uint32_t width;
 *     uint32_t height;
 *     uint32_t reset;
 *     uint8_t numBackBuffers;
 *     uint8_t maxFrameLatency;
 *     uint8_t debugTextScale;
 * }}</pre>
 */
@NativeType("struct bgfx_resolution_t")
public class BGFXResolution extends Struct<BGFXResolution> implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        FORMATCOLOR,
        FORMATDEPTHSTENCIL,
        WIDTH,
        HEIGHT,
        RESET,
        NUMBACKBUFFERS,
        MAXFRAMELATENCY,
        DEBUGTEXTSCALE;

    static {
        Layout layout = __struct(
            __member(4),
            __member(4),
            __member(4),
            __member(4),
            __member(4),
            __member(1),
            __member(1),
            __member(1)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        FORMATCOLOR = layout.offsetof(0);
        FORMATDEPTHSTENCIL = layout.offsetof(1);
        WIDTH = layout.offsetof(2);
        HEIGHT = layout.offsetof(3);
        RESET = layout.offsetof(4);
        NUMBACKBUFFERS = layout.offsetof(5);
        MAXFRAMELATENCY = layout.offsetof(6);
        DEBUGTEXTSCALE = layout.offsetof(7);
    }

    protected BGFXResolution(long address, @Nullable ByteBuffer container) {
        super(address, container);
    }

    @Override
    protected BGFXResolution create(long address, @Nullable ByteBuffer container) {
        return new BGFXResolution(address, container);
    }

    /**
     * Creates a {@code BGFXResolution} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public BGFXResolution(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** @return the value of the {@code formatColor} field. */
    @NativeType("bgfx_texture_format_t")
    public int formatColor() { return nformatColor(address()); }
    /** @return the value of the {@code formatDepthStencil} field. */
    @NativeType("bgfx_texture_format_t")
    public int formatDepthStencil() { return nformatDepthStencil(address()); }
    /** @return the value of the {@code width} field. */
    @NativeType("uint32_t")
    public int width() { return nwidth(address()); }
    /** @return the value of the {@code height} field. */
    @NativeType("uint32_t")
    public int height() { return nheight(address()); }
    /** @return the value of the {@code reset} field. */
    @NativeType("uint32_t")
    public int reset() { return nreset(address()); }
    /** @return the value of the {@code numBackBuffers} field. */
    @NativeType("uint8_t")
    public byte numBackBuffers() { return nnumBackBuffers(address()); }
    /** @return the value of the {@code maxFrameLatency} field. */
    @NativeType("uint8_t")
    public byte maxFrameLatency() { return nmaxFrameLatency(address()); }
    /** @return the value of the {@code debugTextScale} field. */
    @NativeType("uint8_t")
    public byte debugTextScale() { return ndebugTextScale(address()); }

    /** Sets the specified value to the {@code formatColor} field. */
    public BGFXResolution formatColor(@NativeType("bgfx_texture_format_t") int value) { nformatColor(address(), value); return this; }
    /** Sets the specified value to the {@code formatDepthStencil} field. */
    public BGFXResolution formatDepthStencil(@NativeType("bgfx_texture_format_t") int value) { nformatDepthStencil(address(), value); return this; }
    /** Sets the specified value to the {@code width} field. */
    public BGFXResolution width(@NativeType("uint32_t") int value) { nwidth(address(), value); return this; }
    /** Sets the specified value to the {@code height} field. */
    public BGFXResolution height(@NativeType("uint32_t") int value) { nheight(address(), value); return this; }
    /** Sets the specified value to the {@code reset} field. */
    public BGFXResolution reset(@NativeType("uint32_t") int value) { nreset(address(), value); return this; }
    /** Sets the specified value to the {@code numBackBuffers} field. */
    public BGFXResolution numBackBuffers(@NativeType("uint8_t") byte value) { nnumBackBuffers(address(), value); return this; }
    /** Sets the specified value to the {@code maxFrameLatency} field. */
    public BGFXResolution maxFrameLatency(@NativeType("uint8_t") byte value) { nmaxFrameLatency(address(), value); return this; }
    /** Sets the specified value to the {@code debugTextScale} field. */
    public BGFXResolution debugTextScale(@NativeType("uint8_t") byte value) { ndebugTextScale(address(), value); return this; }

    /** Initializes this struct with the specified values. */
    public BGFXResolution set(
        int formatColor,
        int formatDepthStencil,
        int width,
        int height,
        int reset,
        byte numBackBuffers,
        byte maxFrameLatency,
        byte debugTextScale
    ) {
        formatColor(formatColor);
        formatDepthStencil(formatDepthStencil);
        width(width);
        height(height);
        reset(reset);
        numBackBuffers(numBackBuffers);
        maxFrameLatency(maxFrameLatency);
        debugTextScale(debugTextScale);

        return this;
    }

    /**
     * Copies the specified struct data to this struct.
     *
     * @param src the source struct
     *
     * @return this struct
     */
    public BGFXResolution set(BGFXResolution src) {
        memCopy(src.address(), address(), SIZEOF);
        return this;
    }

    // -----------------------------------

    /** Returns a new {@code BGFXResolution} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static BGFXResolution malloc() {
        return new BGFXResolution(nmemAllocChecked(SIZEOF), null);
    }

    /** Returns a new {@code BGFXResolution} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static BGFXResolution calloc() {
        return new BGFXResolution(nmemCallocChecked(1, SIZEOF), null);
    }

    /** Returns a new {@code BGFXResolution} instance allocated with {@link BufferUtils}. */
    public static BGFXResolution create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return new BGFXResolution(memAddress(container), container);
    }

    /** Returns a new {@code BGFXResolution} instance for the specified memory address. */
    public static BGFXResolution create(long address) {
        return new BGFXResolution(address, null);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static @Nullable BGFXResolution createSafe(long address) {
        return address == NULL ? null : new BGFXResolution(address, null);
    }

    /**
     * Returns a new {@code BGFXResolution} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static BGFXResolution malloc(MemoryStack stack) {
        return new BGFXResolution(stack.nmalloc(ALIGNOF, SIZEOF), null);
    }

    /**
     * Returns a new {@code BGFXResolution} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static BGFXResolution calloc(MemoryStack stack) {
        return new BGFXResolution(stack.ncalloc(ALIGNOF, 1, SIZEOF), null);
    }

    // -----------------------------------

    /** Unsafe version of {@link #formatColor}. */
    public static int nformatColor(long struct) { return memGetInt(struct + BGFXResolution.FORMATCOLOR); }
    /** Unsafe version of {@link #formatDepthStencil}. */
    public static int nformatDepthStencil(long struct) { return memGetInt(struct + BGFXResolution.FORMATDEPTHSTENCIL); }
    /** Unsafe version of {@link #width}. */
    public static int nwidth(long struct) { return memGetInt(struct + BGFXResolution.WIDTH); }
    /** Unsafe version of {@link #height}. */
    public static int nheight(long struct) { return memGetInt(struct + BGFXResolution.HEIGHT); }
    /** Unsafe version of {@link #reset}. */
    public static int nreset(long struct) { return memGetInt(struct + BGFXResolution.RESET); }
    /** Unsafe version of {@link #numBackBuffers}. */
    public static byte nnumBackBuffers(long struct) { return memGetByte(struct + BGFXResolution.NUMBACKBUFFERS); }
    /** Unsafe version of {@link #maxFrameLatency}. */
    public static byte nmaxFrameLatency(long struct) { return memGetByte(struct + BGFXResolution.MAXFRAMELATENCY); }
    /** Unsafe version of {@link #debugTextScale}. */
    public static byte ndebugTextScale(long struct) { return memGetByte(struct + BGFXResolution.DEBUGTEXTSCALE); }

    /** Unsafe version of {@link #formatColor(int) formatColor}. */
    public static void nformatColor(long struct, int value) { memPutInt(struct + BGFXResolution.FORMATCOLOR, value); }
    /** Unsafe version of {@link #formatDepthStencil(int) formatDepthStencil}. */
    public static void nformatDepthStencil(long struct, int value) { memPutInt(struct + BGFXResolution.FORMATDEPTHSTENCIL, value); }
    /** Unsafe version of {@link #width(int) width}. */
    public static void nwidth(long struct, int value) { memPutInt(struct + BGFXResolution.WIDTH, value); }
    /** Unsafe version of {@link #height(int) height}. */
    public static void nheight(long struct, int value) { memPutInt(struct + BGFXResolution.HEIGHT, value); }
    /** Unsafe version of {@link #reset(int) reset}. */
    public static void nreset(long struct, int value) { memPutInt(struct + BGFXResolution.RESET, value); }
    /** Unsafe version of {@link #numBackBuffers(byte) numBackBuffers}. */
    public static void nnumBackBuffers(long struct, byte value) { memPutByte(struct + BGFXResolution.NUMBACKBUFFERS, value); }
    /** Unsafe version of {@link #maxFrameLatency(byte) maxFrameLatency}. */
    public static void nmaxFrameLatency(long struct, byte value) { memPutByte(struct + BGFXResolution.MAXFRAMELATENCY, value); }
    /** Unsafe version of {@link #debugTextScale(byte) debugTextScale}. */
    public static void ndebugTextScale(long struct, byte value) { memPutByte(struct + BGFXResolution.DEBUGTEXTSCALE, value); }

}
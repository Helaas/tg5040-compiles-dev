/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.assimp;

import org.jspecify.annotations.*;

import java.nio.*;

import org.lwjgl.*;
import org.lwjgl.system.*;

import static org.lwjgl.system.Checks.*;
import static org.lwjgl.system.MemoryUtil.*;
import static org.lwjgl.system.MemoryStack.*;

/**
 * <pre>{@code
 * struct aiFace {
 *     unsigned int mNumIndices;
 *     unsigned int * mIndices;
 * }}</pre>
 */
@NativeType("struct aiFace")
public class AIFace extends Struct<AIFace> implements NativeResource {

    /** The struct size in bytes. */
    public static final int SIZEOF;

    /** The struct alignment in bytes. */
    public static final int ALIGNOF;

    /** The struct member offsets. */
    public static final int
        MNUMINDICES,
        MINDICES;

    static {
        Layout layout = __struct(
            __member(4),
            __member(POINTER_SIZE)
        );

        SIZEOF = layout.getSize();
        ALIGNOF = layout.getAlignment();

        MNUMINDICES = layout.offsetof(0);
        MINDICES = layout.offsetof(1);
    }

    protected AIFace(long address, @Nullable ByteBuffer container) {
        super(address, container);
    }

    @Override
    protected AIFace create(long address, @Nullable ByteBuffer container) {
        return new AIFace(address, container);
    }

    /**
     * Creates a {@code AIFace} instance at the current position of the specified {@link ByteBuffer} container. Changes to the buffer's content will be
     * visible to the struct instance and vice versa.
     *
     * <p>The created instance holds a strong reference to the container object.</p>
     */
    public AIFace(ByteBuffer container) {
        super(memAddress(container), __checkContainer(container, SIZEOF));
    }

    @Override
    public int sizeof() { return SIZEOF; }

    /** @return the value of the {@code mNumIndices} field. */
    @NativeType("unsigned int")
    public int mNumIndices() { return nmNumIndices(address()); }
    /** @return a {@link IntBuffer} view of the data pointed to by the {@code mIndices} field. */
    @NativeType("unsigned int *")
    public IntBuffer mIndices() { return nmIndices(address()); }

    /** Sets the address of the specified {@link IntBuffer} to the {@code mIndices} field. */
    public AIFace mIndices(@NativeType("unsigned int *") IntBuffer value) { nmIndices(address(), value); return this; }

    /**
     * Copies the specified struct data to this struct.
     *
     * @param src the source struct
     *
     * @return this struct
     */
    public AIFace set(AIFace src) {
        memCopy(src.address(), address(), SIZEOF);
        return this;
    }

    // -----------------------------------

    /** Returns a new {@code AIFace} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed. */
    public static AIFace malloc() {
        return new AIFace(nmemAllocChecked(SIZEOF), null);
    }

    /** Returns a new {@code AIFace} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed. */
    public static AIFace calloc() {
        return new AIFace(nmemCallocChecked(1, SIZEOF), null);
    }

    /** Returns a new {@code AIFace} instance allocated with {@link BufferUtils}. */
    public static AIFace create() {
        ByteBuffer container = BufferUtils.createByteBuffer(SIZEOF);
        return new AIFace(memAddress(container), container);
    }

    /** Returns a new {@code AIFace} instance for the specified memory address. */
    public static AIFace create(long address) {
        return new AIFace(address, null);
    }

    /** Like {@link #create(long) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static @Nullable AIFace createSafe(long address) {
        return address == NULL ? null : new AIFace(address, null);
    }

    /**
     * Returns a new {@link AIFace.Buffer} instance allocated with {@link MemoryUtil#memAlloc memAlloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static AIFace.Buffer malloc(int capacity) {
        return new Buffer(nmemAllocChecked(__checkMalloc(capacity, SIZEOF)), capacity);
    }

    /**
     * Returns a new {@link AIFace.Buffer} instance allocated with {@link MemoryUtil#memCalloc memCalloc}. The instance must be explicitly freed.
     *
     * @param capacity the buffer capacity
     */
    public static AIFace.Buffer calloc(int capacity) {
        return new Buffer(nmemCallocChecked(capacity, SIZEOF), capacity);
    }

    /**
     * Returns a new {@link AIFace.Buffer} instance allocated with {@link BufferUtils}.
     *
     * @param capacity the buffer capacity
     */
    public static AIFace.Buffer create(int capacity) {
        ByteBuffer container = __create(capacity, SIZEOF);
        return new Buffer(memAddress(container), container, -1, 0, capacity, capacity);
    }

    /**
     * Create a {@link AIFace.Buffer} instance at the specified memory.
     *
     * @param address  the memory address
     * @param capacity the buffer capacity
     */
    public static AIFace.Buffer create(long address, int capacity) {
        return new Buffer(address, capacity);
    }

    /** Like {@link #create(long, int) create}, but returns {@code null} if {@code address} is {@code NULL}. */
    public static AIFace.@Nullable Buffer createSafe(long address, int capacity) {
        return address == NULL ? null : new Buffer(address, capacity);
    }

    /**
     * Returns a new {@code AIFace} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack the stack from which to allocate
     */
    public static AIFace malloc(MemoryStack stack) {
        return new AIFace(stack.nmalloc(ALIGNOF, SIZEOF), null);
    }

    /**
     * Returns a new {@code AIFace} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack the stack from which to allocate
     */
    public static AIFace calloc(MemoryStack stack) {
        return new AIFace(stack.ncalloc(ALIGNOF, 1, SIZEOF), null);
    }

    /**
     * Returns a new {@link AIFace.Buffer} instance allocated on the specified {@link MemoryStack}.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static AIFace.Buffer malloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.nmalloc(ALIGNOF, capacity * SIZEOF), capacity);
    }

    /**
     * Returns a new {@link AIFace.Buffer} instance allocated on the specified {@link MemoryStack} and initializes all its bits to zero.
     *
     * @param stack    the stack from which to allocate
     * @param capacity the buffer capacity
     */
    public static AIFace.Buffer calloc(int capacity, MemoryStack stack) {
        return new Buffer(stack.ncalloc(ALIGNOF, capacity, SIZEOF), capacity);
    }

    // -----------------------------------

    /** Unsafe version of {@link #mNumIndices}. */
    public static int nmNumIndices(long struct) { return memGetInt(struct + AIFace.MNUMINDICES); }
    /** Unsafe version of {@link #mIndices() mIndices}. */
    public static IntBuffer nmIndices(long struct) { return memIntBuffer(memGetAddress(struct + AIFace.MINDICES), nmNumIndices(struct)); }

    /** Sets the specified value to the {@code mNumIndices} field of the specified {@code struct}. */
    public static void nmNumIndices(long struct, int value) { memPutInt(struct + AIFace.MNUMINDICES, value); }
    /** Unsafe version of {@link #mIndices(IntBuffer) mIndices}. */
    public static void nmIndices(long struct, IntBuffer value) { memPutAddress(struct + AIFace.MINDICES, memAddress(value)); nmNumIndices(struct, value.remaining()); }

    /**
     * Validates pointer members that should not be {@code NULL}.
     *
     * @param struct the struct to validate
     */
    public static void validate(long struct) {
        check(memGetAddress(struct + AIFace.MINDICES));
    }

    // -----------------------------------

    /** An array of {@link AIFace} structs. */
    public static class Buffer extends StructBuffer<AIFace, Buffer> implements NativeResource {

        private static final AIFace ELEMENT_FACTORY = AIFace.create(-1L);

        /**
         * Creates a new {@code AIFace.Buffer} instance backed by the specified container.
         *
         * <p>Changes to the container's content will be visible to the struct buffer instance and vice versa. The two buffers' position, limit, and mark values
         * will be independent. The new buffer's position will be zero, its capacity and its limit will be the number of bytes remaining in this buffer divided
         * by {@link AIFace#SIZEOF}, and its mark will be undefined.</p>
         *
         * <p>The created buffer instance holds a strong reference to the container object.</p>
         */
        public Buffer(ByteBuffer container) {
            super(container, container.remaining() / SIZEOF);
        }

        public Buffer(long address, int cap) {
            super(address, null, -1, 0, cap, cap);
        }

        Buffer(long address, @Nullable ByteBuffer container, int mark, int pos, int lim, int cap) {
            super(address, container, mark, pos, lim, cap);
        }

        @Override
        protected Buffer self() {
            return this;
        }

        @Override
        protected Buffer create(long address, @Nullable ByteBuffer container, int mark, int position, int limit, int capacity) {
            return new Buffer(address, container, mark, position, limit, capacity);
        }

        @Override
        protected AIFace getElementFactory() {
            return ELEMENT_FACTORY;
        }

        /** @return the value of the {@code mNumIndices} field. */
        @NativeType("unsigned int")
        public int mNumIndices() { return AIFace.nmNumIndices(address()); }
        /** @return a {@link IntBuffer} view of the data pointed to by the {@code mIndices} field. */
        @NativeType("unsigned int *")
        public IntBuffer mIndices() { return AIFace.nmIndices(address()); }

        /** Sets the address of the specified {@link IntBuffer} to the {@code mIndices} field. */
        public AIFace.Buffer mIndices(@NativeType("unsigned int *") IntBuffer value) { AIFace.nmIndices(address(), value); return this; }

    }

}